#include "src/abb.h"
#include <stdio.h>
#include "pa2mm.h"
#include "string.h"

int main()
{
  pa2m_nuevo_grupo("Pruebas de ABB");

  return pa2m_mostrar_reporte();
}
