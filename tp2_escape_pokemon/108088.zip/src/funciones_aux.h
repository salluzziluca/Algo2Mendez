#ifndef __FUNCIONES_AUX_H__
#define __FUNCIONES_AUX_H__
#include "hash.h"
char **hash_obtener_claves (hash_t *hash, char **vector);

#endif // __FUNCIONES_AUX_H__