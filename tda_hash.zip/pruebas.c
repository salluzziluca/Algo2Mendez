#include "src/hash.h"
#include "pa2m.h"

int main()
{
	pa2m_nuevo_grupo("Pruebas de algo");

	return pa2m_mostrar_reporte();
}
