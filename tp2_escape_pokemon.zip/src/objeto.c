#include "objeto.h"
#include "estructuras.h"
#include <stdlib.h>

struct objeto *objeto_crear_desde_string(const char *string)
{
	return NULL;
}
