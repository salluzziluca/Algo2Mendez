#include "estructuras.h"
#include "interaccion.h"
#include <stdlib.h>

struct interaccion *interaccion_crear_desde_string(const char *string)
{
	return NULL;
}
