#include "src/lista.h"
#include "src/pila.h"
#include "src/cola.h"
#include <stdio.h>
#include <stdlib.h>
#include "pa2m.h"

int main() {
  pa2m_nuevo_grupo("Pruebas y mas pruebas");

  return pa2m_mostrar_reporte();
}
